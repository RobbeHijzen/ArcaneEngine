#include "BaseComponent.h"

BaseComponent::BaseComponent(GameObject* pParent)
	: m_Owner{ pParent }
{
}
